﻿using Azure;
using Hospital.API.Data;
using Hospital.API.Models.MainModels;
using Hospital.API.Models.ResponseModels;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Reflection;

namespace Hospital.API.Repository
{
    public class HomeRepository
    {
        private readonly HospitalDbContext _db;

        public HomeRepository(HospitalDbContext db)
        {
            this._db = db;
        }
        public void InsertPharmacy()
        {
            //using var db = new HospitalDbContext();   //parameterless constructor is not added in hsopitaldbcontext.cs file

            if(_db.Pharmacies.Any())
            {
                return;
            }

            var data = new List<Pharmacy>
            {
                new Pharmacy
                {
                    Name = "ABC Pharmacy",
                    PharmacyDetails = new List<PharmacyDetails>
                    {
                        new PharmacyDetails
                        {
                        Name = "ABC Pharmacy", DateAndTime="Mon-Fri : 6:00 AM - 8:00 PM", Phone="+91-9876543210", Location="Porur, Chennai"
                        }
                    }
                },
                new Pharmacy
                {
                    Name = "XYZ Medicals",
                    PharmacyDetails = new List<PharmacyDetails>
                    {
                        new PharmacyDetails
                        {
                        Name = "XYZ Medicals", DateAndTime="Mon-Sun : 10:00 AM - 10:00 PM", Phone="+91-1234567890", Location="Ashok Nagar, Chennai"
                        }
                    }
                },
                new Pharmacy
                {
                    Name = "CMC Medicals",
                    PharmacyDetails = new List<PharmacyDetails>
                    {
                        new PharmacyDetails
                        {
                        Name = "CMC Medicals", DateAndTime="Mon-Fri : 6:00 AM - 8:00 PM", Phone="+91-9988771122", Location="K.K.Nagar, Chennai"
                        }
                    }
                },
                new Pharmacy
                {
                    Name = "Bhama Pharmacy",
                    PharmacyDetails = new List<PharmacyDetails>
                    {
                        new PharmacyDetails
                        {
                        Name = "Bhama Pharmacy", DateAndTime="Mon-Fri : 6:00 AM - 8:00 PM", Phone="+91-1352467890", Location="Valasaravakkam, Chennai"
                        }
                    }
                },
                new Pharmacy
                {
                    Name = "URS Medi",
                    PharmacyDetails = new List<PharmacyDetails>
                    {
                        new PharmacyDetails
                        {
                        Name = "URS Medi", DateAndTime="Mon-Sun : 11:00 AM - 8:00 PM", Phone="+91-3355778809", Location="Porur, Chennai"
                        }
                    }
                },
                new Pharmacy
                {
                    Name = "Hospital Buddy",
                    PharmacyDetails = new List<PharmacyDetails>
                    {
                        new PharmacyDetails
                        {
                        Name = "Hospital Buddy", DateAndTime="Mon-Sat : 10:00 AM - 6:00 PM", Phone="+91-9090898978", Location="Ashok Nagar, Chennai"
                        }
                    }
                },
                new Pharmacy
                {
                    Name = "PNC Medicals",
                    PharmacyDetails = new List<PharmacyDetails>
                    {
                        new PharmacyDetails
                        {
                        Name = "PNC Medicals", DateAndTime="Mon-Fri : 6:00 AM - 8:00 PM", Phone="+91-2463578967", Location="T.Nagar, Chennai"
                        }
                    }
                },
                new Pharmacy
                {
                    Name = "Ganga Pharmacy",
                    PharmacyDetails = new List<PharmacyDetails>
                    {
                        new PharmacyDetails
                        {
                        Name = "Ganga Pharmacy", DateAndTime="Mon-Sun : 10:00 AM - 10:00 PM", Phone="+91-9887766554", Location="Anna Nagar, Chennai"
                        }
                    }
                }


                //wont get updated as the above if condition returns true as the table has 1 record and is not empty

                //new Pharmacy
                //{
                //    Name = "CMC Medicals",
                //    PharmacyDetails = new List<PharmacyDetails>
                //    {
                //        new PharmacyDetails
                //        {
                //        Name = "CMC Medicals", DateAndTime="Mon-Fri : 6:00 AM - 8:00 PM", Phone="+91-9988771122", Location="K.K.Nagar, Chennai"
                //        }
                //    }
                //}
            };

            _db.Pharmacies.AddRange(data);
            _db.SaveChanges();
        }

        public void UpdatePharmacy()
        {
            //if(_db.Pharmacies.Any(p => p.Name == "CMC Medicals" || p.Name == "Bhama Pharmacy"))
            //{
            //    return;
            //}

            var data = new List<Pharmacy>
            {
                new Pharmacy
                {
                    Name = "CMC Medicals",
                    PharmacyDetails = new List<PharmacyDetails>
                    {
                        new PharmacyDetails
                        {
                        Name = "CMC Medicals", DateAndTime="Mon-Fri : 6:00 AM - 8:00 PM", Phone="+91-9988771122", Location="K.K.Nagar, Chennai"
                        }
                    }
                },
                new Pharmacy
                {
                    Name = "Bhama Pharmacy",
                    PharmacyDetails = new List<PharmacyDetails>
                    {
                        new PharmacyDetails
                        {
                        Name = "Bhama Pharmacy", DateAndTime="Mon-Fri : 6:00 AM - 8:00 PM", Phone="+91-1352467890", Location="Valasaravakkam, Chennai"
                        }
                    }
                }
            };

            _db.Pharmacies.AddRange(data);
            _db.SaveChanges();
        }

        public string DeletePharmacyRecord(int id)
        {
            var response = _db.Pharmacies
                            .Include(x => x.PharmacyDetails)
                            .Select(y => new Pharmacy
                            {
                                Id = y.Id,
                                Name = y.Name,
                                PharmacyDetails = y.PharmacyDetails.Select(z => new PharmacyDetails
                                {
                                    Id = z.Id,
                                    Name = z.Name,
                                    DateAndTime = z.DateAndTime,
                                    Phone = z.Phone,
                                    Location = z.Location
                                }).ToList()
                            }).ToList();

            if(!_db.Pharmacies.Any(x => x.Id == id))
            {
                var notFoundResponse = "Record is not there for " + id;
                return notFoundResponse;
            }

            foreach(var res in response)
            {
                if(res.Id == id)
                {
                    var record = _db.Pharmacies.Include(x => x.PharmacyDetails).FirstOrDefault(x => x.Id == id);

                    if (record.PharmacyDetails != null && record.PharmacyDetails.Any())
                    {
                        _db.RemoveRange(record.PharmacyDetails);
                    }
                    _db.Pharmacies.Remove(record);
                    _db.SaveChanges();

                    break;
                }
            }

            return "Success";
        }

        public string InsertPharmacyRecordBasedOnId(Pharmacy data)
        {
            var pharmacyList = _db.Pharmacies.Where(x=>x.Name == data.Name && x.PharmacyDetails[0].Phone == data.PharmacyDetails[0].Phone).ToList();

            if(pharmacyList.Any())
            {
                return "Record Already Exist. Cannot Insert Duplicate Records.";
            }
            else
            {
                var dataToBeAdded = new Pharmacy
                {
                    Name = data.Name,
                    PharmacyDetails = new List<PharmacyDetails>
                    {
                        new PharmacyDetails
                        {
                            Name = data.PharmacyDetails[0].Name,
                            DateAndTime = data.PharmacyDetails[0].DateAndTime,
                            Phone = data.PharmacyDetails[0].Phone,
                            Location = data.PharmacyDetails[0].Location
                        }
                    }
                };

                _db.Pharmacies.AddRange(dataToBeAdded);
                var result = _db.SaveChanges();
                if(!(result > 0))
                {
                    return "Database failed to Save the data";
                }
                
                return "Record Inserted Successfully";
            }
        }

        public string PatchValue(int id, string columnName, string replaceVal)
        {
            var record = _db.Pharmacies.Include(x=>x.PharmacyDetails).Where(x => x.Id == id).FirstOrDefault();
            if (record == null)
            {
                throw new ArgumentException("404 Not Found");
            } 

            switch(columnName.ToLower())
            {
                case "name":
                    record.Name = replaceVal;
                    record.PharmacyDetails.ForEach(d => d.Name = replaceVal);
                    break;
                case "dateandtime":
                    record.PharmacyDetails.ForEach(d => d.DateAndTime = replaceVal);
                    break;
                case "phone":
                    record.PharmacyDetails.ForEach(d => d.Phone = replaceVal);
                    break;
                case "location":
                    record.PharmacyDetails.ForEach(d => d.Location = replaceVal);
                    break;
                default:
                    throw new ArgumentException("Invalid Column Name");
            }

            _db.SaveChanges();

            return "Success";
        }

        public string PatchValueUsingReflections(int id, string columnName, string replaceval)
        {
            var record = _db.Pharmacies.Include(x => x.PharmacyDetails).Where(y => y.Id == id).FirstOrDefault();
            if (record == null)
            {
                throw new ArgumentException("404 Not Found");
            }

            var recordHasColumn = record.GetType().GetProperty(columnName, BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance);

            if (recordHasColumn != null) {
                recordHasColumn?.SetValue(record, replaceval);
            }

            var detailType = typeof(PharmacyDetails);
            var prop = detailType.GetProperty(columnName, BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance);

            if (prop != null)
            {
                record.PharmacyDetails?.ForEach(d => prop.SetValue(d, replaceval));
            }
            
            if (prop == null && recordHasColumn == null)
            {
                throw new ArgumentException($"{columnName} Not Found");
            }

            _db.SaveChanges();
            return "Success";
        }
    }
}
