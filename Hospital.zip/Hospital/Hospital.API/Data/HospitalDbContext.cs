﻿using Hospital.API.Models.MainModels;
using Microsoft.EntityFrameworkCore;

namespace Hospital.API.Data
{
    public class HospitalDbContext : DbContext
    {
        public HospitalDbContext(DbContextOptions dbContextOptions) : base(dbContextOptions) 
        {

        }

        public DbSet<Overview> Overviews { get; set; }
        public DbSet<OurFacility> OurFacilities { get; set; }
        public DbSet<Pharmacy> Pharmacies { get; set; }
    }
}
