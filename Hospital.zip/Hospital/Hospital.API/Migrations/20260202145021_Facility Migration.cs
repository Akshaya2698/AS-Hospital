﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Hospital.API.Migrations
{
    /// <inheritdoc />
    public partial class FacilityMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "OurFacilities",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OurFacilities", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "OurFacilityDetails",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    OurFacilityId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OurFacilityDetails", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OurFacilityDetails_OurFacilities_OurFacilityId",
                        column: x => x.OurFacilityId,
                        principalTable: "OurFacilities",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_OurFacilityDetails_OurFacilityId",
                table: "OurFacilityDetails",
                column: "OurFacilityId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OurFacilityDetails");

            migrationBuilder.DropTable(
                name: "OurFacilities");
        }
    }
}
