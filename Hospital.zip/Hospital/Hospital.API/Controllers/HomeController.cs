﻿using Azure;
using Hospital.API.Data;
using Hospital.API.Models.MainModels;
using Hospital.API.Models.ResponseModels;
using Hospital.API.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Hospital.API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        private readonly HospitalDbContext dbContext;
        private readonly HomeRepository _repo;
        public HomeController(HospitalDbContext dbContext, HomeRepository repo) {
            this.dbContext = dbContext;
            this._repo = repo;
        }

        [HttpGet]
        public IActionResult Overview()
        {
            //From MainModel
            var mainModelResponse = dbContext.Overviews.FirstOrDefault(x => x.Id == 1);

            //From ResponseModel to display in UI
            var response = new OverviewDTO
            {
                Id = mainModelResponse.Id,
                Title = mainModelResponse.Title,
                SubTitle = mainModelResponse.SubTitle,
                Info = mainModelResponse.Info,
                BoxTitle1 = mainModelResponse.BoxTitle1,
                BoxDescription1 = mainModelResponse.BoxDescription1,
                BoxImage1 = mainModelResponse.BoxImage1,
                BoxTitle2 = mainModelResponse.BoxTitle2,
                BoxDescription2 = mainModelResponse.BoxDescription2,
                BoxImage2 = mainModelResponse.BoxImage2,
                BoxTitle3 = mainModelResponse.BoxTitle3,
                BoxDescription3 = mainModelResponse.BoxDescription3,
                BoxImage3 = mainModelResponse.BoxImage3,
            };

            return Ok(response);
        }

        [HttpGet]
        public IActionResult OurFacilities()
        {
            //main model
            var mainOurFacilityModel = dbContext.OurFacilities
                                        .Include(x => x.FacilityDetails)
                                        .ToList();

            //Dto
            var response = dbContext.OurFacilities
                            .Include(x => x.FacilityDetails)
                            .Select(f => new OurFacilityDTO
                            {
                                Id = f.Id,
                                Facility = f.Facility,
                                FacilityDetails = f.FacilityDetails.Select(y => new OurFacilityDetailsDTO
                                {
                                    Id = y.Id,
                                    Title = y.Title,
                                    Description = y.Description,
                                    ImageUrl = y.ImageUrl
                                }).ToList()
                            }).ToList();

            return Ok(response);
        }

        [HttpPost]
        public IActionResult Pharmacy()
        {
            _repo.InsertPharmacy();
            return Ok("Success");
        }

        [HttpPut]
        public IActionResult UpdatePharmacy()
        {
            _repo.UpdatePharmacy();
            return Ok("Updated the data");
        }

        [HttpGet]
        public IActionResult GetPharmacy()
        {
            var mainPharmacyDTO = dbContext.Pharmacies
                                    .Include(x => x.PharmacyDetails)
                                    .ToList();

            var response = dbContext.Pharmacies
                            .Include(x => x.PharmacyDetails)
                            .Select(y => new PharmacyDTO
                            {
                                Id = y.Id,
                                Name = y.Name,
                                PharmacyDetails = y.PharmacyDetails.Select(z => new PharmacyDetailsDTO
                                {
                                    Id = z.Id,
                                    Name = z.Name,
                                    DateAndTime = z.DateAndTime,
                                    Phone = z.Phone,
                                    Location = z.Location
                                }).ToList()
                            }).ToList();
            return Ok(response);
        }

        [HttpDelete("id")]
        public IActionResult DeletePharmacyRecord([FromBody] int id)
        {
            var response = _repo.DeletePharmacyRecord(id);

            if (response == "Success")
            {
                return Ok("Record Deleted Successfully");
            }
            else
            {
                return Ok(response);
            }
        }

        [HttpPost("data")]
        public IActionResult InsertPharmacyRecordBasedOnId([FromBody] Pharmacy data)
        {
            if (data == null)
            {
                return BadRequest();
            }
            var response = _repo.InsertPharmacyRecordBasedOnId(data);
            if(response == "Database failed to Save the data")
            {
                return StatusCode(500);
            }
            return Ok(response);
        }

        [HttpDelete]
        public IActionResult DeleteAllRecordsToResetId()
        {
            try
            {
                //Delete records from child table and then from parent table
                dbContext.Database.ExecuteSqlRaw("DELETE FROM PharmacyDetails");
                dbContext.Database.ExecuteSqlRaw("DELETE FROM Pharmacies");

                //Change the identity value and reset to 1 instead of continuing the id value from where it left
                dbContext.Database.ExecuteSqlRaw("DBCC CHECKIDENT('PharmacyDetails', RESEED, 0)");
                dbContext.Database.ExecuteSqlRaw("DBCC CHECKIDENT('Pharmacies', RESEED, 0)");

                return Ok("Data Deleted from table and Id resetted to 1."); ;
            }
            catch(Exception ex)
            {
                return BadRequest($"Error: " + ex.Message);
            }
            
        }

        [HttpPatch]
        public IActionResult PatchValue([FromQuery] int id, string columnName, string replaceVal)
        {
            var response = _repo.PatchValue(id, columnName, replaceVal);
            return Ok(response);
        }

        [HttpPatch]
        public IActionResult PatchValueUsingReflections([FromQuery] int id, string columnName, string replaceval)
        {
            var response = _repo.PatchValueUsingReflections(id, columnName, replaceval);
            return Ok(response);
        }
    }
}
