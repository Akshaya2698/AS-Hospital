﻿namespace Hospital.API.Models.ResponseModels
{
    public class PharmacyDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<PharmacyDetailsDTO> PharmacyDetails { get; set; }
    }

    public class PharmacyDetailsDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string DateAndTime { get; set; }
        public string Phone { get; set; }
        public string Location { get; set; }

    }
}
