﻿using Hospital.API.Models.MainModels;

namespace Hospital.API.Models.ResponseModels
{
    public class OurFacilityDTO
    {
        public int Id { get; set; }
        public string Facility { get; set; }
        public List<OurFacilityDetailsDTO> FacilityDetails { get; set; }

    }
    public class OurFacilityDetailsDTO
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }

    }
}

