﻿namespace Hospital.API.Models.MainModels
{
    public class Pharmacy
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<PharmacyDetails> PharmacyDetails { get; set; }
    }

    public class PharmacyDetails
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string DateAndTime { get; set; }
        public string Phone { get; set; }
        public string Location { get; set; }

    }
}
