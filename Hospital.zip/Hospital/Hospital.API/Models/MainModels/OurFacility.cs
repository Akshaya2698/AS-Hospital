﻿namespace Hospital.API.Models.MainModels
{
    public class OurFacility
    {
        public int Id { get; set; }
        public string Facility { get; set; }
        public List<OurFacilityDetails> FacilityDetails { get; set; }

    }
    public class OurFacilityDetails
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }

    }

}
