﻿using Hospital.API.Models.MainModels;
using Microsoft.EntityFrameworkCore;

namespace Hospital.API.Data
{
    public class HospitalDbContext : DbContext
    {
        public HospitalDbContext(DbContextOptions dbContextOptions) : base(dbContextOptions) 
        {

        }

        public DbSet<Overview> Overviews { get; set; }
    }
}
