﻿namespace Hospital.API.Models.MainModels
{
    public class Overview
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string SubTitle { get; set; }
        public string Info { get; set; }
        public string BoxTitle1 { get; set; }
        public string BoxDescription1 { get; set; }
        public string BoxImage1 { get; set; }
        public string BoxTitle2 { get; set; }
        public string BoxDescription2 { get; set; }
        public string BoxImage2 { get; set; }
        public string BoxTitle3 { get; set; }
        public string BoxDescription3 { get; set; }
        public string BoxImage3 { get; set; }
    }
}
