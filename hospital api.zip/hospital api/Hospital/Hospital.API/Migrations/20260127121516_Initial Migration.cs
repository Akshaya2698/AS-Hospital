﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Hospital.API.Migrations
{
    /// <inheritdoc />
    public partial class InitialMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Overviews",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SubTitle = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Info = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BoxTitle1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BoxDescription1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BoxImage1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BoxTitle2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BoxDescription2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BoxImage2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BoxTitle3 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BoxDescription3 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BoxImage3 = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Overviews", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Overviews");
        }
    }
}
