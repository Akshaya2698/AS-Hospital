﻿using Azure;
using Hospital.API.Data;
using Hospital.API.Models.MainModels;
using Hospital.API.Models.ResponseModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Hospital.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        private readonly HospitalDbContext dbContext;
        public HomeController(HospitalDbContext dbContext) {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult Overview()
        {
            //From MainModel
            var mainModelResponse = dbContext.Overviews.FirstOrDefault(x => x.Id == 1);

            //From ResponseModel to display in UI
            var response = new OverviewDTO
            {
                Id = mainModelResponse.Id,
                Title = mainModelResponse.Title,
                SubTitle = mainModelResponse.SubTitle,
                Info = mainModelResponse.Info,
                BoxTitle1 = mainModelResponse.BoxTitle1,
                BoxDescription1 = mainModelResponse.BoxDescription1,
                BoxImage1 = mainModelResponse.BoxImage1,
                BoxTitle2 = mainModelResponse.BoxTitle2,
                BoxDescription2 = mainModelResponse.BoxDescription2,
                BoxImage2 = mainModelResponse.BoxImage2,
                BoxTitle3 = mainModelResponse.BoxTitle3,
                BoxDescription3 = mainModelResponse.BoxDescription3,
                BoxImage3 = mainModelResponse.BoxImage3,
            };
            
            return Ok(response);
        }
    }
}
